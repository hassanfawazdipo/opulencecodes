<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "pritice";

$conn = new mysqli($servername, $username, $password, $database);

?>